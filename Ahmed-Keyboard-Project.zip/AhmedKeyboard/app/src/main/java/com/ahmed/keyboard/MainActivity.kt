package com.ahmed.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF171A20.toInt())
        }

        val title = TextView(this).apply {
            text = "Ahmed Keyboard"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "كيبورد لغة أحمد\\n\\n1) فعّل Ahmed Keyboard من إعدادات لوحات المفاتيح.\\n2) ارجع واضغط اختيار الكيبورد.\\n3) اختر Ahmed Keyboard.\\n\\nالكيبورد يعمل محلياً ولا يحتاج اتصال إنترنت."
            textSize = 16f
            setTextColor(0xFFE1E5EA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val enable = Button(this).apply {
            text = "1 - تفعيل الكيبورد"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        val choose = Button(this).apply {
            text = "2 - اختيار Ahmed Keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(enable, LinearLayout.LayoutParams(-1, -2))
        layout.addView(choose, LinearLayout.LayoutParams(-1, -2))
        setContentView(layout)
    }
}
