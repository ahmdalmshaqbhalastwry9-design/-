package com.ahmed.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class AhmedInputMethodService : InputMethodService() {
    // The 28 starter characters selected for Ahmed's alphabet.
    private val letters = listOf(
        "𐌀", "𐌁", "𐌂", "𐌃", "𐌄", "𐌅", "𐌆",
        "𐌇", "𐌈", "𐌉", "𐌊", "𐌋", "𐌌", "𐌍",
        "𐌏", "𐌐", "𐌑", "𐌒", "𐌓", "𐌔", "𐌕",
        "𐌖", "𐌗", "𐌘", "𐌙", "𐌚", "𐌛", "𐌜"
    )

    private val bg = Color.rgb(29, 33, 40)
    private val keyBg = Color.rgb(65, 73, 84)
    private val specialBg = Color.rgb(47, 56, 68)
    private val textColor = Color.WHITE

    override fun onCreateInputView(): View {
        val keyboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(7), dp(4), dp(8))
            setBackgroundColor(bg)
        }

        // Four rows, seven letters per row.
        letters.chunked(7).forEach { rowLetters ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            rowLetters.forEach { letter ->
                row.addView(makeKey(letter) { commit(letter) }, keyParams())
            }
            keyboard.addView(row, rowParams())
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(makeKey("⌫", specialBg) { backspace() }, keyParams(1.0f))
        actions.addView(makeKey("مسافة", specialBg, 14f) { commit(" ") }, keyParams(2.8f))
        actions.addView(makeKey("↵", specialBg) { enter() }, keyParams(1.0f))
        keyboard.addView(actions, rowParams())

        return keyboard
    }

    private fun makeKey(label: String, color: Int = keyBg, size: Float = 23f, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = size
            setTextColor(textColor)
            typeface = Typeface.DEFAULT
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            minHeight = dp(48)
            minimumHeight = dp(48)
            setPadding(dp(1), 0, dp(1), 0)
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(7).toFloat()
            }
            setOnClickListener { action() }
        }
    }

    private fun keyParams(weight: Float = 1f) =
        LinearLayout.LayoutParams(0, dp(48), weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }

    private fun rowParams() =
        LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(1)
        }

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    private fun backspace() {
        val connection = currentInputConnection ?: return
        if (!connection.deleteSurroundingText(1, 0)) {
            connection.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_DEL))
            connection.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_DEL))
        }
    }

    private fun enter() {
        val connection = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
        if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            connection.performEditorAction(action)
        } else {
            commit("\\n")
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
